# Total War: Armor & Weapons MVP
This is the MVP version of the armor and weapons module.