package com.totalwar.armor;

import net.minecraftforge.fml.common.Mod;

@Mod("totalwar_armor")
public class TotalWarArmor {
    public TotalWarArmor() {
        // Initialize items, blocks, or listeners here
    }
}
