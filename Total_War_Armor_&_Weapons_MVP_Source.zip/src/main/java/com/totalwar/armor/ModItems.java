package com.totalwar.armor;

public class ModItems {
    // Register weapons and armor here
}
